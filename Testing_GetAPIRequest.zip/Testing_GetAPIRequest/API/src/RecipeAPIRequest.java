import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONObject;

public class RecipeAPIRequest {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter ingredients separated by commas: ");
            String ingredients = scanner.nextLine();
            scanner.close();

            URL url = new URL("https://api.edamam.com/search?q=" + ingredients
                    + "&app_id=a1750894&app_key=100176f6742263ec462f7fc3cc5d4bd5");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Content-Type", "application/json");

            int status = con.getResponseCode();

            if (status == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                JSONObject jsonResponse = new JSONObject(response.toString());
                JSONArray hitsArray = jsonResponse.getJSONArray("hits");
                System.out.println("\nHere is the list of recipe that we found based on your request \n \n ");
                for (int i = 0; i < hitsArray.length(); i++) {
                    JSONObject hit = hitsArray.getJSONObject(i);
                    JSONObject recipe = hit.getJSONObject("recipe");
                    String title = recipe.getString("label");
                    String URL = recipe.getString("url");
                    System.out.println(title + " - " + URL);
                }
            } else {
                System.out.println("Error: " + status);
            }

            con.disconnect();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
