import org.junit.Test;
import java.net.HttpURLConnection;
import java.net.URL;

import static org.junit.Assert.assertEquals;

public class RecipeAPIRequestTest {

    @Test
    public void testStatusCode() throws Exception {
        String ingredients = "chicken";
        URL url = new URL("https://api.edamam.com/search?q=" + ingredients + "&app_id=a1750894&app_key=100176f6742263ec462f7fc3cc5d4bd5");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("Content-Type", "application/json");

        int status = con.getResponseCode();

        assertEquals(HttpURLConnection.HTTP_OK, status);
    }
}
