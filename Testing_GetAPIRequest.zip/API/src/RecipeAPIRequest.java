import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class RecipeAPIRequest {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter ingredients separated by commas: ");
            String ingredients = scanner.nextLine();
            scanner.close();

            URL url = new URL("https://api.edamam.com/search?q=" + ingredients + "&app_id=a1750894&app_key=100176f6742263ec462f7fc3cc5d4bd5");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Content-Type", "application/json");

            int status = con.getResponseCode();

            if (status == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                System.out.println(response.toString());
            } else {
                System.out.println("Error: " + status);
            }

            con.disconnect();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
